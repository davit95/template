<?php

return [
    'delimiters' => ',;',

    'glue' => ',',

    'normalizer' => 'mb_strtolower',
];
