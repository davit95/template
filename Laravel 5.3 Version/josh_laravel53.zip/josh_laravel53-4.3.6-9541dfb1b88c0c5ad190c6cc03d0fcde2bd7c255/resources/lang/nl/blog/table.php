<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'title'       => 'Titel',
    'comments'      => 'Aantal reacties',
    'created_at' => 'Gemaakt op',
    'actions'	 => 'Acties',

);
