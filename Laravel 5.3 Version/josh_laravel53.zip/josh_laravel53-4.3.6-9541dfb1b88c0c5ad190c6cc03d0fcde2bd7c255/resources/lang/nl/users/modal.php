<?php

/**
* Language file for user delete modal
*
*/
return array(

    'body'			=> 'Weet je zeker dat je deze gebruiker wilt verwijderen? Deze actie is niet terug te draaien.',
    'cancel'		=> 'Cancel',
    'confirm'		=> 'Verwijder',
    'title'         => 'Verwijder gebruiker',

);
