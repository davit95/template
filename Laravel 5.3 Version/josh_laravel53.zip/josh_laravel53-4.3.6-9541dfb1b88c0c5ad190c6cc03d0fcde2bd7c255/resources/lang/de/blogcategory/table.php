<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Name',
    'blogs'      => 'Anzahl der Blogs',
    'created_at' => 'Erstellt am',
    'actions'	 => 'Aktionen',

);
