<?php

/**
* Language file for group delete modal
*
*/
return array(

    'title'         => 'Gruppe Löschen',
    'body'			=> 'Sind Sie sicher, dass Sie diese Gruppe löschen möchten? Dieser Vorgang kann nicht rückgängig gemacht werden.',
    'cancel'		=> 'Abbrechen',
    'confirm'		=> 'Löschen',

);
