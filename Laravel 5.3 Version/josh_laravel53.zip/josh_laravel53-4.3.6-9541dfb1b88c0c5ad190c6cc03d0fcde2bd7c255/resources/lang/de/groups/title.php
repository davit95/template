<?php
/**
* Language file for group section titles
*
*/

return array(

    'create'			=> 'Neue Gruppe erstellen',
    'edit' 				=> 'Gruppe bearbeiten',
    'management'	=> 'Gruppe verwalten',

);
