<?php
/**
* Language file for general strings
*
*/
return array(

    'no'  			=> 'Нет',
    'noresults'  	=> 'Нет резутатов',
    'yes' 			=> 'Да',

);
