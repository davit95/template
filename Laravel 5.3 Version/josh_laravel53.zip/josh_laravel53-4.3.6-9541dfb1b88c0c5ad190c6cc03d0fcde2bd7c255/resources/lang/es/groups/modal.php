<?php

/**
* Language file for group delete modal
*
*/
return array(

    'title'         => 'Borrar Grupo',
    'body'			=> 'Está seguro que quiere borrear este grupo? Esto es irreversible.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Borrar',

);
