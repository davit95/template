<?php

/**
 * Language file for delete modal
 *
 */
return array(

    'title'         => 'Delete item',
    'body'			=> 'Are you sure to delete this item? This operation is irreversible.',
    'cancel'		=> 'Cancel',
    'confirm'		=> 'Delete',

);
