<?php
/**
* Language file for group section titles
*
*/

return array(

    'create'			=> 'Create New Group',
    'edit' 				=> 'Edit Group',
    'management'	=> 'Manage Groups',
    'groups' => 'Groups',
    'groups_list' => 'Groups List',

);
