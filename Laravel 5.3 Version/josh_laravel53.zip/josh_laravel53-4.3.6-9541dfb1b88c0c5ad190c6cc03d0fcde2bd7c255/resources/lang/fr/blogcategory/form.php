<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Nom de la catégorie du blog',
    'general' 		=> 'General',
);
