<?php
/**
* Language file for group table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Nom',
    'users'      => "Nb d'utilisateurs",
    'created_at' => 'Créé le',
    'actions'	 => 'Actions',

);
