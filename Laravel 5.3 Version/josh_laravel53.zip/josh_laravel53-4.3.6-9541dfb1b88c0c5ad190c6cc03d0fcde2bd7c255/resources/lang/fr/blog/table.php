<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'title'       => 'Title',
    'comments'      => 'No. of Comments',
    'created_at' => 'Created at',
    'actions'	 => 'Actions',

);
