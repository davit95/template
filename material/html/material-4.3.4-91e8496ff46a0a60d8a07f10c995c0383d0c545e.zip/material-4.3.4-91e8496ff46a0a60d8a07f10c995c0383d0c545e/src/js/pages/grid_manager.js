 $(document).ready(function() {
     $.material.init();
        $("#mycanvas").gridmanager({
            debug: 1
        });
    });