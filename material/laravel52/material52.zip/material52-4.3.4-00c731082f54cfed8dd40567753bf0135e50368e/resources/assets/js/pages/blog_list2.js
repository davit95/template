$(document).ready(function() {
    $('#table2').dataTable();
});
